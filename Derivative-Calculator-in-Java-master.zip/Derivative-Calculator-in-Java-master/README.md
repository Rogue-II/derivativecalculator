# Derivative-Calculator-in-Java
A simple derivative calculator in Java; includes a few options: chain rule, product rule, power rule, and log rule. - Vighnesh Souda &amp; Gensen Choy @ 2014.
